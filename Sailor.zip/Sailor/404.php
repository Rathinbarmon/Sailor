<?php get_header();?> 
	<section id="content">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="text-center">
 				<h2 class="error">404</h2>
				<p class="lead"><?php _e( 'Sorry your requested page not exist.', 'sailor' ); ?></p>
				<?php get_search_form(); ?>
				<p class="lead"></p>
				</div>
		</div>
		</div>
	</div>
	</section>
<?php get_footer();?>

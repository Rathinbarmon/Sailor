<?php get_header();?> 
<section id="content">
	<div class="container">
		<div class="row"> 
		
			<div class="col-lg-8">
			<h1><?php
				if(is_category()){
					single_cat_title();
				}
				elseif(is_tag()){
					single_tag_title();
				}
				elseif(is_author()){
					echo'Author Archives: '.get_the_author();
					rewind_posts();
				}
				elseif(is_day()){
					echo' Daily Archives: '.get_the_date();
				}
				elseif(is_month()){
					echo' Monthly Archives: '.get_the_date('F Y');
				}
				elseif(is_year()){
					echo' Yearly Archives: '.get_the_date('Y');
				}
				else{
					echo'This ';
				}
			    ?></h1>
			    <?php while(have_posts()):the_post();?>
				<article> 
						<div class="post-image">
							<div class="post-heading">
								<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
							</div>
							<?php the_post_thumbnail('full',array(
							    'class'=>'img-responsive'
							));?> 
						</div>
						<p>
						  <?php the_excerpt();?>
 						</p>
						<div class="bottom-article">
							<ul class="meta-post">
								<li><i class="fa fa-calendar"></i> <a href="<?php the_permalink();?>"> <?php the_date();?></a></li>
								<li><i class="fa fa-user"></i> <?php the_author();?></li>
								<?php if(the_tags());?>
								<li><i class="fa fa-folder-open"></i><a href="<?php the_permalink();?>"> <?php the_tags();?></a></li>
 								<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
							</ul>
							<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
						</div>
				</article>
				<?php endwhile;?>
                <div id="pagination">				
				    <?php the_posts_pagination( array(
				        'prev_text'          => __( '<< Previous page', 'sailor' ),
				        'next_text'          => __( 'Next page >>', 'sailor' ),
				        'screen_reader_text'          => __( ' ', 'sailor' ),
 			        ));?>  
				</div>
			</div> 
		</div>
	</div>
</section>
 
<?php get_footer();?>
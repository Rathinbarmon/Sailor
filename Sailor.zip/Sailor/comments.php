<div id="comments">
<?php if ( post_password_required() ) : ?>
	<p><?php _e( 'This post is password protected. Enter the password to view any type of comments.', 'sailor' ); ?></p>
</div>
<?php
return;
endif;
if ( have_comments() ) : ?>
	<h3 id="comments-title">
		<?php comments_number(); ?>
	</h3>
	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) { ?>
		<div class="navigation"><?php _e( 'Pages: ', 'sailor' ); paginate_comments_links( array('prev_text' => '', 'next_text' => '') ) ?></div>
	<?php }?>	
	<ol class="commentlist">
		<?php wp_list_comments(array('callback' => 'sailor_comment','type' => 'comment')); ?>
		<?php wp_list_comments(array('callback' => 'sailor_comment','type' => 'pings')); ?>
	</ol>
	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) { ?>
		<div class="navigation"><?php _e( 'Pages: ', 'sailor' ); paginate_comments_links( array('prev_text' => '', 'next_text' => '') ) ?></div>
	<?php }?>
<?php endif; 
 comment_form(); 
?>
</div>

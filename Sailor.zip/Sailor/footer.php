<?php global $sailor; ?> 
<?php if($sailor['FO']==1):?> 
<footer>
    <?php if($sailor['fwa']==1):?> 
	<div class="container">
	    <div class="row">
			<?php dynamic_sidebar('fs');?>
		</div>
	</div> 
    <?php endif;?> 
    <?php if($sailor['lfo']==1):?> 
	<div id="sub-footer">
		<div class="container">
			<div class="row">
			<?php if($sailor['cpo']==1):?> 
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span> <?php echo $sailor['cp'];?></a>
						</p>
					</div>
				</div>
			<?php endif;?>
				
			<?php if($sailor['sis']==1):?> 
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="<?php echo $sailor['fb'];?>" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="<?php echo $sailor['tw'];?>" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="<?php echo $sailor['ln'];?>" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="<?php echo $sailor['pt'];?>" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="<?php echo $sailor['gp'];?>" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			<?php endif;?>
			</div>
		</div>
	</div> 
    <?php endif;?>
	</footer>
<?php endif;?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>  
<?php wp_footer();?>
</body>
</html>
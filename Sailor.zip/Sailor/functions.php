<?php 

require_once('functions/set_up.php');
require_once('menu/menu.php');
require_once('functions/css_js.php');
require_once('functions/sidebar.php');
require_once('functions/comment.php');
require_once('functions/sort-code.php');
require_once('inc/ReduxCore/framework.php'); 
require_once('inc/sample/config.php'); 

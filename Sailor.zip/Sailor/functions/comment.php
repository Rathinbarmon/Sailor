
<?php if ( ! function_exists( 'sailor_comment' ) ) :
	function sailor_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case '' :
		?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<div class="comment-body">
				<div class="comment-author vcard">
				<?php 
					if ($comment->comment_parent) {
						$parent_comment = get_comment($comment->comment_parent);
						echo '<cite class="fn">' .get_comment_author_link() .'</cite>';
						printf( __(' in reply to <i>%1$s</i> on %2$s at %3$s:','sailor' ), $parent_comment->comment_author, get_comment_date(__('F j, Y','sailor')), get_comment_time(__('g:i A','sailor')) ); 
					}
					else {
						printf( __('<cite class="fn">%s</cite>','sailor'), get_comment_author_link() ); 
						/* translators: 1: date, 2: time */
						printf( __( ' on %1$s at %2$s:', 'sailor' ), get_comment_date(__('F j, Y','sailor')),  get_comment_time(__('g:i A','sailor')) ); 
					}
					edit_comment_link( __( '(Edit)', 'sailor' ), ' ' );	?>
				</div>
			
				<?php if ( $comment->comment_approved == '0' ) : ?>
					<em><?php _e( 'Your comment is awaiting moderation.', 'sailor' ); ?></em><br/>
				<?php endif; ?>
			<?php comment_text(); ?>
			</div>
			<?php echo get_avatar( $comment, 50 ); ?>
			<?php comment_reply_link( array_merge( $args, array('before'=> '<div class="reply">', 'after' => '</div>', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
	<?php
		break;
		case 'pingback'  :
		case 'trackback' :
	?>
	<li class="pingback">
	<p><?php comment_author_link(); ?>   <?php edit_comment_link( __('(Edit)', 'sailor'), ' ' ); ?></p>
	<?php
	break;
	endswitch;
}
endif;
<?php function sailor_style_script(){
 
 	wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
 	wp_register_style( 'flexslider', get_template_directory_uri() . '/plugins/flexslider/flexslider.css' );
 	wp_register_style( 'cubeportfolio', get_template_directory_uri() . '/css/cubeportfolio.min.css' ); 
 	wp_register_style( 'style', get_template_directory_uri() . '/css/style.css' );
 	wp_register_style( 'default', get_template_directory_uri() . '/skins/default.cs' );
 	wp_register_style( 'bg1', get_template_directory_uri() . '/sbodybg/bg1.css' );
	 
	wp_enqueue_style( 'bootstrap');
	wp_enqueue_style( 'flexslider');
	wp_enqueue_style( 'cubeportfolio'); 
	wp_enqueue_style( 'style');
	wp_enqueue_style( 'default');
	wp_enqueue_style( 'bg1');
	 
	
 	wp_register_script( 'jquery', get_template_directory_uri() . '/js/jquery.min.js');
 	wp_register_script( 'modernizr', get_template_directory_uri() . '/js/modernizr.custom.js');
 	wp_register_script( 'easing', get_template_directory_uri() .'/js/jquery.easing.1.3.js');
 	wp_register_script( 'bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js' );
 	wp_register_script( 'appear', get_template_directory_uri() . '/js/jquery.appear.js' );
 	wp_register_script( 'stellar', get_template_directory_uri() . '/js/stellar.js' );
 	wp_register_script( 'classie', get_template_directory_uri() . '/js/classie.js' );
 	wp_register_script( 'uisearch', get_template_directory_uri() . '/js/uisearch.js' );
 	wp_register_script( 'cubeportfolio', get_template_directory_uri() . '/js/jquery.cubeportfolio.min.js' );
 	wp_register_script( 'prettify', get_template_directory_uri() . '/js/google-code-prettify/prettify.js' );
 	wp_register_script( 'animate', get_template_directory_uri() . '/js/animate.js' );
 	wp_register_script( 'custom', get_template_directory_uri() . '/js/custom.js' );
  

    wp_enqueue_script('jquery');
    wp_enqueue_script('modernizr');
    wp_enqueue_script('easing');
    wp_enqueue_script('bootstrap');
    wp_enqueue_script('appear');
    wp_enqueue_script('stellar');
    wp_enqueue_script('classie');
    wp_enqueue_script('uisearch');
    wp_enqueue_script('cubeportfolio');
    wp_enqueue_script('prettify');
    wp_enqueue_script('animate');
    wp_enqueue_script('custom');
}
add_action('wp_enqueue_scripts','sailor_style_script');
<?php
function sailor_setup(){
	
	load_theme_textdomain( 'sailor', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'custom-background' );
	add_theme_support( 'post-thumbnails' ); 
    add_image_size('about',300,300,true);
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	) );
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'sailor' ), 
	));
    function default_menu(){ 
	    echo'<ul class="navbar nav">';
	    if(is_user_logged_in()){
		    echo'<li><a href="'.home_url().'/wp-admin/nav-menus.php"> Create Your Menu </a></li>';
	    }
	    else{ 
		    echo'<li><a href="'.home_url().'"> Home </a></li>';
	    }
	    echo'</ul>';
    }	
}
add_action( 'after_setup_theme', 'sailor_setup' ); 
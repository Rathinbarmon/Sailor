<?php 

function widget_init(){
	register_sidebar( array(
		'name'          => __( 'Left sidebar Widget Area', 'sailor' ),
		'id'            => 'ls',
		'description'   => __( 'Edit this section.', 'sailor' ),
		'before_widget' => '<aside class="left-sidebar"><div class="widget">',
		'after_widget'  => '</div></aside>',
		'before_title'  => '<h5 class="widgetheading">',
		'after_title'   => '</h5>',
	) );
	register_sidebar( array(
		'name'          => __( 'Right sidebar Widget Area', 'sailor' ),
		'id'            => 'rs',
		'description'   => __( 'Edit this section.', 'sailor' ),
		'before_widget' => '<aside class="right-sidebar"><div class="widget">',
		'after_widget'  => '</div></aside>',
		'before_title'  => '<h5 class="widgetheading">',
		'after_title'   => '</h5>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Widget Area', 'sailor' ),
		'id'            => 'fs',
		'description'   => __( 'Edit this section.', 'sailor' ),
		'before_widget' => '<div class="col-lg-3"><div class="widget">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4><ul class="cat">',
	) );
}
add_action('widgets_init','widget_init');


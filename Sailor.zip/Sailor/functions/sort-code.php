<?php

function sailor_heading($atts,$content){
	$headingg = shortcode_atts(array(
	    'position'=>'center', 
	),$atts);
	
	return "<h1 align='".$headingg['position']."'>".$content."</h1>";
} 
add_shortcode('heading','sailor_heading');


function sailor_pricingbox($atts,$content){
	ob_start();
	$properties = extract(shortcode_atts(array(
	    'title'=>'center',
        'price'=>'20',	
        'st'=>'24*7',		
        'ftd '=>'30 Days',	
	),$atts));
	
	?>
	
	
	<?php while(have_posts()):the_post();?>
			<div class="col-lg-4">
				<div class="pricing-box-alt">
					<div class="pricing-heading">
						<h3><?php $properties['title']?></strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>&#36;<?php $properties['price']?></h6>
					</div>
					<div class="pricing-content">
						<ul>
							<li><i class="icon-ok"></i> <?php $properties['price']?></li>
							<li><i class="icon-ok"></i><?php $properties['st']?> support available</li>
							<li><i class="icon-ok"></i> No hidden fees</li>
							<li><i class="icon-ok"></i><?php $properties['ftd']?>   </li>
							<li><i class="icon-ok"></i> Stop anytime easily</li>
						</ul>
					</div>
					<div class="pricing-action">
						<a href="<?php the_permalink();?>" class="btn btn-medium btn-theme"><i class="icon-bolt"></i> Register now</a>
					</div>
				</div>
			</div>
			<?php endwhile;?> 
	
	
	
	
	<?php $pricingbox = ob_get_clean();
	return $pricingbox;
} 
add_shortcode('pricingbox','sailor_pricingbox');
?>    
<?php
/**
 * The Header for our theme 
 * @package WordPress
 * @subpackage  Sailor
 * @since Sailor   1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<?php global $sailor;?>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
     <?php wp_head();?>
</head>
<body <?php body_class();?>> 
<div id="wrapper">
	<!-- start header -->
	<header> 
	        <?php if($sailor['tb']==1):?>
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
						<?php if($sailor['po']==1):?>
							<ul class="topleft-info"> 
								<li><i class="fa fa-phone"></i> 
									<?php  echo $sailor['phn'];?>
								</li> 
							</ul>
						<?php endif;?>	
						</div>
						<div class="col-md-6"> 
						<div id="sb-search" class="sb-search">
							<?php if($sailor['sb']==1):?>
								<form>
									<input class="sb-search-input" placeholder="Enter your search term..." type="text" value="" name="s" id="search">
									<input class="sb-search-submit" type="submit" name="s" value="">
									<span class="sb-icon-search" title="Click to start searching"></span>
								</form>
							<?php endif;?>
							</div> 
						</div>
					</div>
				</div>
			</div>
            <?php endif;?>			
			
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
					<?php if($sailor['lv']==1):?>
                    <a class="navbar-brand" href="<?php bloginfo( 'home' ); ?>">
					    <img src="<?php  echo $sailor['logo']['url'];?>" alt="" width="199" height="52" />
					</a>
					<?php endif;?>
                </div>
                <div class="navbar-collapse collapse ">
				<?php  
			        wp_nav_menu(array(
		                'theme_location'=>'primary',
			            'menu_class'=>'nav navbar-nav',
			            'fallback_cb'=>'default_menu',
			            'container'=>' ',
			            'walker'=>new wp_bootstrap_navwalker()
		            )); 
		        ?>  
                </div>
            </div>
        </div>
	</header> 
	<!-- end header -->
	<?php if($sailor['hib']==1):?>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
			 <?php if(is_home()){?>
				<ul class="breadcrumb"> 
					<li><a href="<?php bloginfo('home');?>"><i class="fa fa-home"></i></a></li> 
					 
				</ul> 
			 <?php } else { ?> 
				 <ul class="breadcrumb"> 
						<li><a href="<?php bloginfo('home');?>"><i class="fa fa-home"></i></a></li> 
						<li class="active"><?php the_title();?> </li>  
				</ul>
			 <?php } ?>   
			</div>
		</div>
	</div>
	</section>
	<?php endif;?>
<?php 
global $sailor;
get_header();?> 
<section id="content">
	<div class="container">
		<div class="row">
		
		<!---layout Full width--->
		    <?php if($sailor['bls']==1):?> 
				<div class="col-lg-12">
					<?php while(have_posts()):the_post();?>
					<article>
							<div class="post-image">
								<div class="post-heading">
									<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
								</div>
								<?php the_post_thumbnail('full',array(
									'class'=>'img-responsive'
								));?> 
							</div>
							<p>
							  <?php the_content();?>
							</p>
							<div class="bottom-article">
								<ul class="meta-post">
									<li><i class="fa fa-calendar"></i>  <?php the_date();?></li>
									<li><i class="fa fa-user"></i><a href="#"> <?php the_author();?></a></li>
									<li><i class="fa fa-folder-open"></i><a href="#"> <?php the_tags();?></a></li>
									<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
								</ul>
								<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
							</div>
					</article>
					<?php endwhile;?> 
					<div id="pagination">				
						<?php the_posts_pagination( array(
							'prev_text'          => __( '<< Previous page', 'sailor' ),
							'next_text'          => __( 'Next page >>', 'sailor' ),
							'screen_reader_text'          => __( ' ', 'sailor' ),
						 ));?>  
				    </div>
				</div>
			<?php endif;?>
			
			
		<!---layout Right sidebar--->
		
		<?php if($sailor['bls']==2):?>  
			<div class="col-lg-8">
			    <?php while(have_posts()):the_post();?>
				<article>
						<div class="post-image">
							<div class="post-heading">
								<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
							</div>
							<?php the_post_thumbnail('full',array(
							    'class'=>'img-responsive'
							));?> 
						</div>
						<p>
						  <?php the_excerpt();?>
 						</p>
						<div class="bottom-article">
							<ul class="meta-post">
								<li><i class="fa fa-calendar"></i>  <?php the_date();?></li>
								<li><i class="fa fa-user"></i><a href="#"> <?php the_author();?></a></li>
								<li><i class="fa fa-folder-open"></i><a href="#"> <?php the_tags();?></a></li>
 								<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
							</ul>
							<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
						</div>
				</article>
				<?php endwhile;?> 
				<div id="pagination">				
					<?php the_posts_pagination( array(
						'prev_text'          => __( '<< Previous page', 'sailor' ),
						'next_text'          => __( 'Next page >>', 'sailor' ),
						'screen_reader_text'          => __( ' ', 'sailor' ),
					 ));?>  
			    </div>
			</div>   
			
			<div class="col-lg-4">
				<?php dynamic_sidebar('ls');?>  
			</div>
		<?php endif;?>
		
		
		    
		<!---layout left sidebar--->
		
			<?php if($sailor['bls']==3):?>  
                <div class="col-lg-4">
				    <?php dynamic_sidebar('ls');?> 	
				</div>
				
				<div class="col-lg-8">
					<?php while(have_posts()):the_post();?>
					<article>
							<div class="post-image">
								<div class="post-heading">
									<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
								</div>
								<?php the_post_thumbnail('full',array(
									'class'=>'img-responsive'
								));?> 
							</div>
							<p>
							  <?php the_excerpt();?>
							</p>
							<div class="bottom-article">
								<ul class="meta-post">
									<li><i class="fa fa-calendar"></i>  <?php the_date();?></li>
									<li><i class="fa fa-user"></i><a href="#"> <?php the_author();?></a></li>
									<li><i class="fa fa-folder-open"></i><a href="#"> <?php the_tags();?></a></li>
									<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
								</ul>
								<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
							</div>
					</article>
					<?php endwhile;?>
                    <div id="pagination">				
						<?php the_posts_pagination( array(
							'prev_text'          => __( '<< Previous page', 'sailor' ),
							'next_text'          => __( 'Next page >>', 'sailor' ),
							'screen_reader_text'          => __( ' ', 'sailor' ),
						 ));?>  
					</div>					
				</div> 
		    <?php endif;?> 
			
          <!---two sidebar layout--->
			
			<?php if($sailor['bls']==4):?>  
			     <div class="col-lg-4">
				    <?php dynamic_sidebar('ls');?> 	
				</div>
				<div class="col-lg-4">
					<?php while(have_posts()):the_post();?>
					<article>
							<div class="post-image">
								<div class="post-heading">
									<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
								</div>
								<?php the_post_thumbnail('full',array(
									'class'=>'img-responsive'
								));?> 
							</div>
							<p>
							  <?php the_excerpt();?>
							</p>
							<div class="bottom-article">
								<ul class="meta-post">
									<li><i class="fa fa-calendar"></i>  <?php the_date();?></li>
									<li><i class="fa fa-user"></i><a href="#"> <?php the_author();?></a></li>
									<?php if(the_tags());?>
									<li><i class="fa fa-folder-open"></i><a href="#"> <?php the_tags();?></a></li>
									<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
								</ul>
								<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
							</div>
					</article>
					<?php endwhile;?> 
					<div id="pagination">				
						<?php the_posts_pagination( array(
							'prev_text'          => __( '<< Previous page', 'sailor' ),
							'next_text'          => __( 'Next page >>', 'sailor' ),
							'screen_reader_text'          => __( ' ', 'sailor' ),
						 ));?>  
					</div>
				</div>   
				
				 <div class="col-lg-4">
				    <?php dynamic_sidebar('ls');?> 	
				</div> 
			<?php endif;?>
			
			
			 <!---three column layout--->
			
			<?php if($sailor['bls']==5):?> 
				<?php while(have_posts()):the_post();?>
				<div class=" tcl col-lg-4">
					<article>
							<div class="post-image">
								<div class="post-heading">
									<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
								</div>
								<?php the_post_thumbnail('full',array(
									'class'=>'img-responsive'
								));?> 
							</div>
							<p>
							  <?php the_excerpt();?>
							</p>
							<div class="bottom-article">
								<ul class="meta-post">
									<li><i class="fa fa-calendar"></i>  <?php the_date();?></li>
									<li><i class="fa fa-user"></i><a href="#"> <?php the_author();?></a></li>
									<?php if(the_tags());?>
									<li><i class="fa fa-folder-open"></i><a href="#"> <?php the_tags();?></a></li>
									<li><i class="fa fa-comments"></i><a href="#"><?php comments_popup_link();?></a></li>
								</ul>
								<a href="<?php the_permalink();?>" class="readmore pull-right">Continue reading <i class="fa fa-angle-right"></i></a>
							</div>
					</article>
				</div> 
				<?php endwhile;?>
                <div id="pagination">				
					<?php the_posts_pagination( array(
						'prev_text'          => __( '<< Previous page', 'sailor' ),
						'next_text'          => __( 'Next page >>', 'sailor' ),
						'screen_reader_text'          => __( ' ', 'sailor' ),
					 ));?>  
				</div> 	
			<?php endif;?>

          <!---end layout--->
		   
          

		  
	    </div>
	</div>
</section>
<?php get_footer();?>
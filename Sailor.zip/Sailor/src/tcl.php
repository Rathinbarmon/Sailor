<?php global sailor;?>
